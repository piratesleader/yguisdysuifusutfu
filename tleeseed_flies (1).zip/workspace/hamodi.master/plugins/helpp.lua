do

function run(msg, matches)
return [[
☼الاوامر
!info
Displays general info about the SuperGroup
☑معلومات
يعرض معلومات عامه عن المجموعه
!admins
Returns SuperGroup admins list
☑الادمنيه
يعرض الادمنيه المجموعه
!owner
Returns group owner
☑مالك
مالك المجموعه {المدير}
!modlist
Returns Moderators list
☑المراقبين
يعرض قائمه المراقبين
!bots
Lists bots in SuperGroup
☑قائمه البوتات في المجموعه
!who
Lists all users in SuperGroup
☑قائمه الاعضاء في المجموعه
!block
Kicks a user from SuperGroup
*Adds user to blocked list*
☑حضر
حضر المستخدم من المجموعه عن طريق الرد 
!ban
Bans user from the SuperGroup
☑حضر
حضر عضو عن طريق ايدي او @ اليوزر
!unban
Unbans user from the SuperGroup
☑فك الحضر
فك الحضر عن طريق ايدي او @ اليوزر
!id
Return SuperGroup ID or user id
*For userID s: !id @username or reply !id*
☑ايدي الشخص
لاظهار ايدي شخص فقط @ اليوز او عن طريق الرد
!id from
☑ايدي المجموعه
!kickme
☑مغادر من المجموعه
!setowner
Sets the SuperGroup owner
☑اضافه مدير
اضافه مدير للبوت في المجموعه
!promote
Promote a SuperGroup moderator
☑اضافه ادمن
لاضافه ادمن فقط @ يوزر او ايدي
!demote
Demote a SuperGroup moderator
☑لازاله الادمن
لازاله ادمن فقط @يوزر او ايدي
!setname
Sets the chat name
☑اضافه اسم
اضافه اسم للمجموعة
!setphoto
Sets the chat photo
☑تغير الصوره
لتغير صوره المجموعه
!setrules
Sets the chat rules
☑اضافه قوانين للمجموعه
!setabout
Sets the about section in chat info(members list)
☑لاضافه وصف
لاضافه وصف للمجموعه اكتب الوصف
!save [value] <text>
Sets extra info for chat
☑حفظ قيمه والنص
يحدد معلومات اصافيه للمجموعه
!get [value]
Retrieves extra info for chat by value
☑يسترجع ماحفظته
!newlink
Generates a new group link
☑انشاء رابط
لانشاء رابط للمجموعه
!link
Retireives the group link
☑رابط
لاضهار رابط المجموعه
!rules
Retrieves the chat rules
☑القوانين
لاضهار قوانين المجموعه
!lock
[links|flood|spam|Arabic|member|rtl|sticker|contacts|strict]

☑قفل
الرابط و التكرار و الكليشه و اللغه العربيه و الاضافه
و الاشاره و الملصقات و الاتصالات و صارمه
!unlock
[links|flood|spam|Arabic|member|rtl|sticker|contacts|strict]
☑الغاء القفل
الرابط و التكرار و الكليشه و اللغه العربيه و الاضافه
والاشاره و الملصقات و التصالات و الصارم
!mute [all|audio|gifs|photo|video|service]
☑قفل 
الكل و البصمات و الصور المتحركه و الصور و الفديو
والخدمه
!unmute
[all|audio|gifs|photo|video|service]
☑فتح 
الكل و البصمات و الصور المتحركه و الصور و الفديو
و الخدمه
!setflood
☑تحديد عدد التكرار
!settings
☑الاعدادات
!muteslist
☑باند عام
!mute list
☑قائمه المكتومين
!muteuser [username]
☑كتم عضو محدد
!banlist
☑قائمه المحضورين
!clean [rules|about|modlist|mutelist]
☑تنظيف
القوانين و الوصف و الادمنيه و الباند
!del
☑حذف رساله بالرد
!public [yes|no]
☑المراقبه نعم او لا
!res [username]
☑دقه الشخص بالكامل
!log
☑السجل 
!loveyou
☑زيارتي @Mylifeinpain
]]
end

return {
description = "Shows bot q", 
usage = "help Shows bot q",
patterns = {
"الاوامر$"
},
run = run 
}
end