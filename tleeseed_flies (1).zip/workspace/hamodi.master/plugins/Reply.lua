do
ws = {}
rs = {}

-- some examples of how to use this :3 
ws[1] = "هلو" -- msg 
rs[1] = "  هْـٌﮩٌﮧٌ﴿🙃﴾ۙﮩٌـ୭ٌ୭ـْلوُّات†😻☝️  " -- reply

ws[2] = "بوت" -- msg
rs[2] = "مازا تريد منه🙄🍃" -- reply

ws[3] = "شلونكم" -- msg
rs[3] = "تٌـٌـمـــ༄༅ـٌـٌإأإآمـ و اٍْنـْﱡِـ👈youـٍُتٍۜة ☺️🌹" -- reply

ws[4] = "بوسني" -- msg 
rs[4] = " ٲٳٲمــﮨ﴿💋﴾ﮨﮨﮨﮨ﴿😚﴾ﮨــوٱآاﮨـٍٰۣۗح✵❤ لحليكك/ج " -- reply

ws[5] = "احبك" -- msg 
rs[5] = "صـ❲❥❳ـہۣۙدگـﮧِّ† 😻🙌 خـجـ😅ـلت" -- reply

ws[6] = "عبود" -- msg 
rs[6] = "نايم😴"-- reply

ws[7] = "باي" -- msg 
rs[7] = " ﭘــًًٍٍّّّْــًٍٍُُّّّّْ✋ــٍٍُّّّاأٍٍّّأٍّﯾﮧٍّ🏃  " -- reply

ws[8] = "اكرهك" -- msg 
rs[8] = "عـلساس آٌنـّ'ℳέ'ـّي أحـبٍّـٍـٍـُـِՀօvεٍـٍـٍكـُّ💓 😝" -- reply

ws[9] = "اتفل" -- msg 
rs[9] = "خخخخـ😩ـخخخ تفـ💦ـووووو💦💦" -- reply

ws[10] = "سوسو" -- msg 
rs[10] = "اﯛﯛﯛﯛيــْـــلـٍـيٍِ❥ عـلـ🍃ـيهه صـ🌚❤️ـاكه" -- reply

ws[11] = "كتكوته" -- msg 
rs[11] = " مشعوطه والهيبه تصطر😌🍃" -- reply

ws[12] = "مرحبا" -- msg 
rs[12] = "مـراحـ🌹ـب نـورت/ي🌹🍃" -- reply

ws[13] = "انجب" -- msg 
rs[13] = "لا❌لا تحجي على الضلع لا❌لا بل45 ع راسك😒👆" -- reply

ws[14] = "زاحف" -- msg 
rs[14] = "زاحف ع اختك مثلا🌚☝️🏽️" -- reply

ws[15] = "ميمي" -- msg 
rs[15] = "صـ😻ـاكة الكـgяθυρـٍْـْْروب 🌚❤️" -- reply


ws[16] = "قناتي" -- msg 
rs[16] = "https://telegram.me/kenam_bot_plus_saad7m" -- reply

ws[17] = "حمودي" -- msg 
rs[17] = "صـ😻ــاك الكـgяθυρـٍْـْْروب 🌚🌹"
-- the main function
ws[18] = "رورو" -- msg 
rs[18] = "قاهرتكم🐸🍃" -- reply

ws[19] = "طن" -- msg 
rs[19] = "كش عاع🌚✌️🏻" -- reply

ws[20] = "بتيخه" -- msg 
rs[20] = "ضـ🌚❤️ــلعة عــ😴🍃ـلــوش" -- reply

ws[21] = "السلام عليكم" -- msg 
rs[21] = "ۆعلـِْ♡̨̐ـِْيگمَ آلسَـِْ♡̨̐ـِْامَ" -- reply

ws[22] = "مرض" -- msg 
rs[22] = "بـحلـكك 😴َ" -- rep

ws[23] = "😒" -- msg 
rs[23] = "ﺷﺒﮧ❃ہيكہ/ج.  كالب خـلـ🌚ـقتك🚶🏻" -- rep

ws[24] = "🌚" -- msg
rs[24] = "منور صخام الجدر😹☝" -- rep

ws[25] = "بوسه" -- msg
rs[25] = "امــہـ😘😚😘😚😘ــہــواااااح" -- rep

ws[26] = "شبيك" -- msg
rs[26] = "ديٌّــ﴿🌝🚬﴾ــًُي" -- rep

ws[27] = "وين" -- msg
rs[27] = "بالــســ🚗ــيــارﮭﮧ" -- rep

ws[28] = "انته وين" -- msg
rs[28] = "بالــبــ🏠ــيــت" -- rep

ws[29] = "وينك" -- msg
rs[29] = "بالــســ🚗ــيــارﮭﮧ" -- rep

ws[30] = "شكرا" -- msg
rs[30] = "{ •• الـّ~ـعـفو •• }" -- rep

ws[31] = "ولو" -- msg
rs[31] = "شُـگـ{ôħᎯɴêȘ}ــرآآ" -- rep

ws[23] = "تمام" -- msg
rs[23] = "⌣{دِْۈۈۈۈ/يّارٌبْ_مـْو_يـّوّمٌ/ۈۈۈۈمْ}⌣" -- rep

ws[33] = "دوم" -- msg
rs[33] = "⌣{يـّـٌدِْۈۈ/عّزٌگ-ۈنَبْضّ قَلبْگ/ۈۈمْ}⌣" -- rep

ws[34] = "منور" -- msg
rs[34] = "نِْـِْـــِْ([💡])ِْــــًِـًًْـــِْـِْـِْـورِْكِْ" -- rep

ws[35] = "ها" -- msg
rs[35] = "هاي اچون چقله هاي🌚" -- rep

ws[36] = "دخن" -- msg
rs[36] = "🚬 😌" -- rep
function run( msg, matches )
	-- just a local variables that i used in my algorithm  
	local i = 0; local w = false

	-- the main part that get the message that the user send and check if it equals to one of the words in the ws table :)
	-- this section loops through all the words table and assign { k } to the word index and { v } to the word itself 
	for k,v in pairs(ws) do
		-- change the message text to uppercase and the { v } value that toke form the { ws } table and than compare it in a specific pattern 
		if ( string.find(string.upper(msg.text), "^" .. string.upper(v) .. "$") ) then
			-- assign the { i } to the index of the reply and the { w } to true ( we will use it later )
			i = k; w = true;
		end
	end

	-- check if { w } is not false and { i } not equals to 0
	if ( (w ~= false) and (i ~= 0) ) then
		-- get the receiver :3 
		R = get_receiver(msg)
		-- send him the proper message from the index that { i } assigned to
		send_large_msg ( R , rs[i] );
	end
	
	-- don't edit this section
	if ( msg.text == "about" ) then
		if ( msg.from.username == "Mouamle" ) then
			R = get_receiver(msg)
			send_large_msg ( R , "Made by @Mouamle" );
		end
	end 

end



return {
	patterns = {
		"(.*)"		
  	},
  	run = run
} 


end