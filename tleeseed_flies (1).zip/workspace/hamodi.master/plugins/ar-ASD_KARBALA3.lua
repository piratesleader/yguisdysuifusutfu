--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY SAJJAD NOORI                   ▀▄ ▄▀ 
▀▄ ▄▀     BY SAJAD NOORI (@SAJJADNOORI)    ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY SAJJAD NOORI          ▀▄ ▄▀   
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔸

يعمل البوت على مجموعات سوبر تصل الى5k عضو 🔷

     ≪تم صنع البوت بواسطة المطور≫
                      『 @SAJJADNOORI 』
            🔹#Dev #SAJJADNOORI🔹
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(dev)$",
},
run = run 
}
end
